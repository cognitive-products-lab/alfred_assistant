---
name: Avatar or animation idea
about: Suggest an avatar expression, animation or interaction state
title: "[Avatar] "
labels: avatar, animation
assignees: ""
---

## Idea

## User context

## Visual notes

## Technical notes
