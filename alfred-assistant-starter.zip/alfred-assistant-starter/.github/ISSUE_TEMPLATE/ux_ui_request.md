---
name: UX/UI suggestion
about: Suggest an improvement for ALFRED interface or user experience
title: "[UX/UI] "
labels: ux, ui
assignees: ""
---

## What should be improved?

## Why does it matter?

## Suggested idea

## Accessibility considerations
